def pk(m):
    p=m
    k=0
    for t in p:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            k+=1
    return k            
#print(k)        