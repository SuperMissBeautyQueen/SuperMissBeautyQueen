from solution import equ
from Negative import negative
from NotEqualTo import check
from Addzero import addZero
def find(pk1,pk2,pk3):
    try:
        ak1=check(pk1)
        #print(ak1)
        ak2=check(pk2)
        #print(ak2)
        ak3=check(pk3)
        #print(ak3)
        
        aka1=ak1.split('=')
        aka2=ak2.split('=')
        aka3=ak3.split('=')
        
        aka1[0]=addZero(aka1[0],aka2[0],aka3[0],aka1[0])
        #print(aka1[0])
        
        aka2[0]=addZero(aka1[0],aka2[0],aka3[0],aka2[0])
        #print(aka2[0])
        aka3[0]=addZero(aka1[0],aka2[0],aka3[0],aka3[0])
        #print(aka3[0])
        
        if (ord(aka1[0][0])==45):
            akn1=list(equ(negative(aka1[0])))
            if (ord(aka1[1][0])==45):
                aka1[1]=(-1)*float(aka1[1])
            else:
                aka1[1]=float('-'+aka1[1])
        else:
            akn1=list(equ(aka1[0]))
            aka1[1]=float(aka1[1])
        
        
        if (ord(aka2[0][0])==45):
            akn2=list(equ(negative(aka2[0])))
            if (ord(aka2[1][0])==45):
                aka2[1]=(-1)*float(aka2[1])
            else:
                aka2[1]=float('-'+aka2[1])
        else:
            akn2=list(equ(aka2[0]))
            aka2[1]=float(aka2[1])
        
        
        if (ord(aka3[0][0])==45):
            akn3=list(equ(negative(aka3[0])))
            if (ord(aka3[1][0])==45):
                aka3[1]=(-1)*float(aka3[1])
            else:
                aka3[1]=float('-'+aka3[1])
        else:
            akn3=list(equ(aka3[0]))
            aka3[1]=float(aka3[1])        
        
        
        a1,a2,a3=(akn1[0],akn2[0],akn3[0])
        b1,b2,b3=(akn1[1],akn2[1],akn3[1])
        c1,c2,c3=(akn1[2],akn2[2],akn3[2])
        d1,d2,d3=(aka1[1],aka2[1],aka3[1])
        X1,X2,X3=(akn1[3],akn2[3],akn3[3])
        Y1,Y2,Y3=(akn1[4],akn2[4],akn3[4])
        Z1,Z2,Z3=(akn1[5],akn2[5],akn3[5])
        #print(X1,X2,X3,Y1,Y2,Y3,Z1,Z2,Z3)
        
        detA=a1*((b2*c3)-(b3*c2))-b1*((a2*c3)-(a3*c2))+c1*((a2*b3)-(a3*b2))
        
        A11=((-1)**2)*((b2*c3)-(b3*c2))
        A12=((-1)**3)*((a2*c3)-(a3*c2))
        A13=((-1)**4)*((a2*b3)-(a3*b2))
        
        A21=((-1)**3)*((b1*c3)-(b3*c1))
        A22=((-1)**4)*((a1*c3)-(a3*c1))
        A23=((-1)**5)*((a1*b3)-(a3*b1))
        
        A31=((-1)**4)*((b1*c2)-(b2*c1))
        A32=((-1)**5)*((a1*c2)-(a2*c1))
        A33=((-1)**6)*((a1*b2)-(a2*b1))
        M1=A11*d1+A21*d2+A31*d3
        M2=A12*d1+A22*d2+A32*d3
        M3=A13*d1+A23*d2+A33*d3
        
        if detA != 0 and ord(X1)==ord(X2)==ord(X3) and ord(Y1)==ord(Y2)==ord(Y3) and ord(Z1)==ord(Z2)==ord(Z3):
            ans1=(M1/detA)
            ans2=(M2/detA)
            ans3=(M3/detA)
            return (X1,Y2,Z3,ans1,ans2,ans3)
        elif detA!=0:
            return (1,1,1,1,1,1)
        elif detA==0:
            return (0,0,0,0,0,0)
        else:
            return (2,2,2,2,2)
#        print("A11=%d,A12=%d,A13=%d"%(A11,A12,A13))
#        print("A21=%d,A22=%d,A23=%d"%(A21,A22,A23))
#        print("A31=%d,A32=%d,A33=%d"%(A31,A32,A33))
#        print(detA)
#        print(ak1,'\n',a1+b1+c1+d1,X1,Y1,Z1)
#        print(ak2,'\n',a2+b2+c2+d2,X2,Y2,Z2)
#        print(ak3,'\n',a3+b3+c3+d3,X3,Y3,Z3)
    except:
        return 0
#print(find())        