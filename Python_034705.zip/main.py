from kivy.app import App
from kivy.lang import Builder
from kivy.properties import ObjectProperty
from kivy.uix.widget import Widget
from kivy.core.window import Window
from threevar import find
from twovariablelinear import finds
from varnum import pk
from Negative import negative
from kivy.animation import Animation
import time
class MyLayout(Widget):
    Builder.load_file('calc1.kv')
    def bk(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'b'
    def one(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'1'
    def two(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'2'
    def three(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'3'
    def four(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'4'
    def five(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'5'
    def six(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'6'
    def seven(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'7'
    def eight(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'8'
    def nine(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'9'
    def zero(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'0'
    def plus(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'+'
    def minus(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'-'
    def ak(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'a'
    def akanksha(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'x'
    def tannu(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'='
    def payal(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'z'
    def khushaboo(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'y'
    def rot(self):
    		self.ids.calc_input.text=self.ids.calc_input.text+'\n'
    def p(self):
        self.ids.calc_input.text=self.ids.calc_input.text+'p' 
    def q(self):
        self.ids.calc_input.text=self.ids.calc_input.text+'q'
    def r(self):
        self.ids.calc_input.text=self.ids.calc_input.text+'r'                
    def ck(self):
         self.ids.calc_input.text=self.ids.calc_input.text+'c'       		
    def clear(self):
       self.ids.calc_input.text=''
       self.ids.calc_input.font_size=50
    def submit(self):
               try:
                   akanksha=self.ids.calc_input.text
                   self.ids.calc_input.text=self.ids.calc_input.text
                   akn=akanksha.split("\n")
                   k1=pk(akn[0])
                   k2=pk(akn[1])
                   if(akanksha.count('\n')==2 and(k1<=3 or k2<=3)):
                       ksha=list(find(akn[0],akn[1],akn[2]))
                       self.ids.calc_input.font_size=50
                       #self.ids.calc_input.text=str(ksha)
                       if ksha==[0,0,0,0,0,0]:
                           self.ids.calc_input.text="System of equation is \n Inconsistent."
                       elif ksha==[1,1,1,1,1,1]:
                           self.ids.calc_input.text="Variables are not matching."
                       elif ksha==[2,2,2,2,2,2]:
                           self.ids.calc_input.text="Wrong Equation."
                       else:
                           self.ids.calc_input.text=str(ksha[0])+'='+str("{:.2f}".format(float(ksha[3])))+' , '+str(ksha[1])+'='+str("{:.2f}".format(float(ksha[4])))+" , "+str(ksha[2])+'='+str("{:.2f}".format(float(ksha[5])))+'\n____________________________\n'+akanksha
                   elif(akanksha.count('\n')==1and(k1<=2 or k2<=2)):
                        ksha=list(finds(akn[0],akn[1]))
                        self.ids.calc_input.font_size=50
                        if ksha==[0,0,0,0,0,0]:
                           self.ids.calc_input.text="System of equation is \n inconsistent."
                        elif ksha==[1,1,1,1,1,1]:
                           self.ids.calc_input.text="System of equation is \n inconsistent.."
                        elif ksha==[2,2,2,2,2,2]:
                           self.ids.calc_input.text="Wrong Equation."
                        else:
                            self.ids.calc_input.text=str(ksha[0])+'='+str("{:.2f}".format(float(ksha[2])))+' , '+str(ksha[1])+'='+str("{:.2f}".format(float(ksha[3])))+'\n____________________________\n'+akanksha
               except:
                   self.ids.calc_input.text=self.ids.calc_input.text
                                                            
    def reset(self):
       #self.ids.calc_input.background_color=(1,1,1,1)
       self.ids.calc_input.font_size=50
       self.ids.calc_input.text='Enter Your Equation As:-\na1x±b1y±c1z=d1            a1x±b1y=d1\na2x±b2y±c2z=d2            a2x±b2y=d2\na3x±by±c3z=d3'
       #self.ids.calc_input.#background_color=(1,1,0,1)
       #self.ids.calc_input.color=(0,0,0,1)             
    def wish(self , widget ,*args):
    	self.ids.calc_input.text=self.ids.calc_input.text+'.'
    def back(self):	
	    	Back=self.ids.calc_input.text
	    	at=list(Back)
	    	an=0
	    	kan=''
	    	for u in at:
	    		an+=1
	    	nu=1
	    	if an==1:
	    		pk=''
	    	elif Back=='':
	    		pk=''
	    	else:
		    	for sha in at:
		    		kan=kan+sha
		    		nu+=1
		    		if (nu>(an-1)):
		    			pk=kan
		    			break
	    	self.ids.calc_input.text=pk
class Calculator(App):
    def build(self):
       
       return MyLayout()

Calculator().run()