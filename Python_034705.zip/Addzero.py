from Negative import negative
from twobythree import variables
def addZero(p1,p2,p3,p6):

    p4=negative(p6)
    p5=""
    q1=list(p1)
    q2=list(p2)
    q3=list(p3)
    q4=list(p4)
    a=""
    b=""
    c=""
    ak1=""
    ak2=""
    ak3=""
    i,j,k,kr,kri,d=(0,0,0,0,0,0)
    for t in q1:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            a=a+t
            i+=1
    
    ak1=list(a)
    
    a=""
    for t in q2:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            b=b+t
            j+=1 
    
    ak2=list(b)
                   
    a=""
    for t in q3:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            c=c+t
            k+=1
    
    ak3=list(c)
    
    d=""        
    
    
    #print(ak1)
    #print(ak2)
    #print(ak4)
    
    if j<=i and k<=i:
        kr=i
        aka=ak1
    elif i<=j and k<=j:
        kr=j
        aka=ak2    
    elif j<=k and i<=k:
        kr=k
        aka=ak3
    if kr !=3 :
        aka=variables(p1+p2+p3)        
    #print(aka)
    for t in q4:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            d=d+t
            kri+=1        
    ak4=list(d)
    ak4.append("")
    ak4.append("")
    print(ak4)
    m=0
    #print(aka)
    if kri==kr==3 and aka[0] == ak4[0] and aka[1]==ak4[1] and aka[2]==ak4[2]:
        return p4
    elif kri<=kr :
        if aka[0] != ak4[0] and aka[1]==ak4[0] and aka[2]==ak4[1]:
            q4.insert(0,"0"+aka[0]+"+")
            for i in q4:
                p5=p5+i
            return p5
        elif aka[0] == ak4[0] and aka[1]!=ak4[1] and aka[2]==ak4[1]:
            ma=0
            for i in q4:
                if ord(i)==43 or ord(i)==45:
                    break
                ma +=1                
            q4.insert(ma,'+0'+aka[1])
            for i in q4:
                p5=p5+i
            return p5
        elif aka[0] == ak4[0] and aka[1]==ak4[1] and aka[2]!=ak4[2]:
            p5=""
            q4.append("+0"+aka[2])
            for i in q4:
                   p5=p5+i
            return p5
        else:
            raise ValueError()
#print(addZero(input("enter"),input("enter"),input("enter"),input("enter")))                                  