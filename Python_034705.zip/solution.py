from Negative import negative
def equ(p):
    l=p
    if l[0]==chr(43) or l[0]=='-':
        l=negative(l)
    b=""
    a1,y,x,z=("","","","")
    b1=""
    c1=""
    c=""
    try:
        l1=l.split('-')
        l2=l.split('+')
        if l.count('+')==2 and len(l2)==3:
            t=l2[0]
            for t in l2[0]:
                if not(48<=ord(l2[0][0])<=57):
                    b='1'
                    a1=float(b)
                    x=l2[0][0]
                    break
                elif(48<=ord(t)<=57 or ord(t)==46) :
                    b=b+t
                if(65<=ord(t)<=98) or (97<=ord(t)<=122):
                    a1=float(b)
                    x=t
                    
            b=''
            for t in l2[1]:
                if not (48<=ord(l2[1][0])<=57) :
                    b='1'
                    b1=float(b)
                    y=l2[1][0]
                    break
                elif (48<=ord(t)<=57 or ord(t)==46):
                                    b=b+t
                if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                                    b1=float(b)
                                    y=t
            b=""
            for t in l2[2]:
                if not(48<=ord(l2[2][0])<=57):
                     b='1'
                     c1=float(b)
                     z=l2[2][0]
                     break
                elif (48<=ord(t)<=57 or ord(t)==46):
                    b=b+t
                if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                    c1=float(b)
                    z=t  
        if len(l1)==2:
            p=l1[0].count('+')
            if p>0:
                t1=l1[0].split('+')
                b=''
                for t in t1[0]:
                    if not(48<=ord(t1[0][0])<=57):
                        b='1'
                        ta=float(b)
                        x=t1[0][0]
                        break
                    elif(48<=ord(t)<=57 or ord(t)==46):
                        b=b+t
                    if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                        ta=float(b)
                        x=t
                a1=ta
                b=""
                for t in t1[1]:
                    if not (48<=ord(t1[1][0])<=57):
                        b='1'
                        nn=float(b)
                        y=t1[1][0]
                        break
                    elif (48<=ord(t)<=57 or ord(t)==46):
                        b=b+t
                    if(65<=ord(t)<=98) or (97<=ord(t)<=122):
                        nn=float(b)
                        y=t
                b1=nn
            else:
                b=''
                for t in l1[0]:
                    if not (48<=ord(l1[0][0])<=57):
                        b='1'
                        u=float(b)
                        x=l1[0][0]
                        break
                    elif (48<=ord(t)<=57 or ord(t)==46 ) :
                        b=b+t
                    if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                        u= float(b)
                        x=t
                a1=u
            q=l1[1].count('+')
            if q>0:
                t1=l1[1].split('+')
                b=""
                for t in t1[0]:
                    if not (48<=ord(t1[0][0])<=57):
                        b='-1'
                        ta=float(b)
                        y=t1[0][0]
                        break
                    elif(48<=ord(t)<=57 or ord (t)==46):
                        b=b+t
                    if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                        ta= float('-'+b)
                        y=t
                b1=ta
                b=""
                for t in t1[1]:
                    if not(48<=ord(t1[1][0])<=57):
                        b='1'
                        nn=float(b)
                        z=t1[1][0]
                        break
                    elif(48<=ord(t)<=57 or ord (t)==46):
                        b=b+t
                    if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                        nn=float(b)
                        z=t
                c1=nn
            else:
                b=""
                for t in l1[1]:
                    if not(48<=ord(l1[1][0])<=57):
                        b='-'+'1'
                        u=float(b)
                        z=l1[1][0]
                        break
                    elif(48<=ord(t)<=57 or ord (t)==46):
                        b=b+t
                    if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                        u=float('-'+b)
                        z=t
                c1=u
        if len(l1) ==3:
            b=""
            c=""
            k=0
            t=""
            for t in l1[0]:
                if not(48<=ord(l1[0][0])<=57) :
                    b=1
                    c=float(b)
                    x=l1[0][0]
                    break
                elif (48<=ord(t)<=57 or ord(t)==46) :
                    b=b+t
                if(65<=ord(t)<=98) or (97<=ord(t)<=122):
                    c=float(b)
                    x=t
            a1=c
            b=""
            t=""
            for t in l1[1]:
                if not(48<=ord(l1[1][0])<=57) :
                    b='-'+'1'
                    d=float(b)
                    y=l1[1][0]
                    break
                elif(48<=ord(t)<=57 or ord(t)==46):
                    b=b+t
                if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                    d= float('-'+b)
                    y=t
            b1=d
            b=''
            t=""
            for t in l1[2]:
                if not(48<=ord(l1[2][0])<=57) :
                    b='-'+'1'
                    e=float(b)
                    z=l1[2][0]
                    break
                elif(48<=ord(t)<=57 or ord(t)==46):
                    b=b+t
                if (65<=ord(t)<=98) or (97<=ord(t)<=122):
                    e= float('-'+b)
                    z=t
            c1=e                       
        return(a1,b1,c1,x,y,z)
    except:
        return 0 
#print(equ(input('enter')))                  