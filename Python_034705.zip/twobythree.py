def variables(y):
    p,q,r=("","","")
    for i in y:
        if(65<=ord(i)<=98) or (97<=ord(i)<=122)and p!=i:
            p=i
            break
    for i in y:
        if(65<=ord(i)<=98) or (97<=ord(i)<=122)and p!=i and (ord(i)==ord(p)+1):
            q=i
            break
    for i in y:
        if(65<=ord(i)<=98) or (97<=ord(i)<=122)and p!=i and q!=i and ord(i)==ord(q)+1:
            r=i
            break

    sa=p+q+r
    return sa                       
#print(variables(input("input")))        