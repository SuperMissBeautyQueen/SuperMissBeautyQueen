from solution import equ
from NotEqualTo import check
from Negative import negative
from add1 import addzero

def finds(pk1,pk2):
    ak1=check(pk1)
    ak2=check(pk2)
    
    aka1=ak1.split('=')
    aka2=ak2.split('=')
    sk1=aka1[0]
    sk2=aka2[0]
    aka1[0]=addzero(sk1,sk2,sk1)+'+0z'
    aka2[0]=addzero(sk1,sk2,sk2)+'+0z'
    #print(aka1[0],aka2[0])
    akn1=list(equ(aka1[0]))
    akn2=list(equ(aka2[0]))
    
    if(ord(sk1[0][0])==45):
        akn1=list(equ(negative(aka1[0])))
        if (ord(aka1[1][0])==45):
            aka1[1]=(-1)*float(aka1[1])
        else:
            aka1[1]=float('-'+aka1[1])
    else:
        akn1=list(equ(aka1[0]))
        aka1[1]=float(aka1[1])
        
        
    if (ord(sk2[0][0])==45):
        akn2=list(equ(negative(aka2[0])))
        if (ord(aka2[1][0])==45):
            aka2[1]=(-1)*float(aka2[1])
        else:
            aka2[1]=float('-'+aka2[1])
    else:
        akn2=list(equ(aka2[0]))
        aka2[1]=float(aka2[1])
        
    a1,a2=(akn1[0],akn2[0])
    b1,b2=(akn1[1],akn2[1])
    d1,d2=(aka1[1],aka2[1])
    X1,X2=(akn1[3],akn2[3])
    Y1,Y2=(akn1[4],akn2[4])  
    
    detA=(a1*b2-a2*b1)
    
    A11=((-1)**2)*b2
    A12=((-1)**3)*a2
    
    A21=((-1)**3)*b1
    A22=((-1)**4)*a1
    
    M1=A11*d1+A21*d2
    M2=A12*d1+A22*d2

#print(detA)
    #ans1=M1/detA
#    ans2=M2/detA
    if detA != 0 and ord(X1)==ord(X2)and ord(Y1)==ord(Y2):
        ans1=M1/detA
        ans2=M2/detA
        return (X1,Y1,ans1,ans2)
    elif detA!=0:
        return (1,1,1,1,1,1)
    elif detA==0:
            return (0,0,0,0,0,0)
    else:
            return (2,2,2,2,2)           