def negative(p):
	l=p
	if l[0]=='-':
		pq=''
		for p in l:
			if p=='-':
				p='+'
			elif p=='+':
				p='-'
					
			pq=pq+p
				
		tk=list(pq)
		del tk[0]	
		pk=''
		for ak in  tk:
			pk=pk+ak
		l=pk
		return l
	else :
		return l