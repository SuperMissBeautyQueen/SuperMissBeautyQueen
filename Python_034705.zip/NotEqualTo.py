def check(m):
    try:
        pk=""
        akn=""
        pr=""
        i=1
        if m.count('=')==1 and (m.count('=')==1 and m[m.index("=")+1] !=chr(48)):
            return m
        elif m.count('=')==0 or (m.count('=')==1 and m[m.index("=")+1]==chr(48)):
            if m.count('=')==1:
                mk=m.split('=')
                m=mk[0]
            p=len(m)
            for t in range(p):
                pk=pk+m[p-i]
                if ord(m[p-i])==43 or  ord(m[p-i])==45:
                    break
                i+=1           
            ak=0
            pi=p-i
            for s in range(ak,pi):
                akn=akn+m[ak]
                ak+=1
            ksh=len(pk)
            i=1
            for u in range(ksh):
                pr=pr+pk[ksh-i]
                i+=1
            if ord(pr[0])==45:
                m=akn+'='+str((-1)*float(pr))
                return m
            else:
                m=akn+'='+str((-1)*float(pr))
                return m
    except:
        return m+"=0" 
#print(check(input('enter=>\n')))                