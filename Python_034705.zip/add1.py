from Negative import negative
def addzero(p1,p2,p6):

    p4=negative(p6)
    p5=""
    q1=list(p1)
    q2=list(p2)
    #q3=list(p3)
    q4=list(p4)
    a=""
    b=""
    c=""
    ak1=""
    ak2=""
    ak3=""
    i,j,k,kr,kri,d=(0,0,0,0,0,0)
    for t in q1:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            a=a+t
            i+=1
    
    ak1=list(a)
    
    a=""
    for t in q2:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            b=b+t
            j+=1 
    
    ak2=list(b)
                   
   # a=""
#    for t in q3:
#        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
#            c=c+t
#            k+=1
#    
#    ak3=list(c)
    
    d=""        
    
    
    #print(ak1)
    #print(ak2)
    #print(ak4)
    
    if j<=i:
        kr=i
        aka=ak1
    else:
        kr=j
        aka=ak2    
#    elif j<=k and i<=kr:
#        kr=k
#        aka=ak3
    #print(aka)
    for t in q4:
        if(65<=ord(t)<=98) or (97<=ord(t)<=122):
            d=d+t
            kri+=1        
    print(kri,kr)
    ak3=list(d)
    ak3.append("")
    
    m=0
    print(aka)
    if kri==kr and aka[0] == ak3[0] and aka[1]==ak3[1]:
        return p4
    elif kri<kr:
        if aka[0] != ak3[0] and aka[1]==ak3[0]:
            q4.insert(0,"0"+aka[0]+"+")
            for i in q4:
                p5=p5+i
            print(p5)   
            return p5
        elif aka[0] == ak3[0] and aka[1]!=ak3[1]:
            ma=0
            for i in q4:
                if ord(i)==43 or ord(i)==45:
                    break
                ma +=1                
            q4.insert(ma,'+0'+aka[1])
            for i in q4:
                p5=p5+i
            print(p5)
            return p5
        else:
            raise ValueError()
#            p5=
#            q4.append("+0"+aka[2])
#            for i in q4:
#                   p5=p5+i
#            return p5
#        else:
#            raise ValueError()
#print(addzero(input('enter'),input('enter'),input('enter')))                             